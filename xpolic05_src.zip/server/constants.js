const FRAME_RATE = 4;
const GRID_SIZE = 30;
const OBSTICLES = 10;

module.exports = {
  FRAME_RATE,
  GRID_SIZE,
  OBSTICLES,
}
